# Dynamic Widget Maker
This is an Android application for creating and customizing home screen widgets.